#include <QGuiApplication>
#include <QQmlApplicationEngine>

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;
    QObject::connect(
        &engine,
        &QQmlApplicationEngine::objectCreationFailed,
        &app,
        []() { QCoreApplication::exit(-1); },
        Qt::QueuedConnection);

    //engine.loadFromModule("00_Canvas", "Canvas_0");
    //engine.loadFromModule("00_Canvas", "Canvas_1");
    //engine.loadFromModule("00_Canvas", "Canvas_2");
    //engine.loadFromModule("00_Canvas", "Canvas_3_gradient");
    //engine.loadFromModule("00_Canvas", "Canvas_4_shadow");
    //engine.loadFromModule("00_Canvas", "Canvas_5_clip");
    //engine.loadFromModule("00_Canvas", "Canvas_6_move");
    //engine.loadFromModule("00_Canvas", "Canvas_7_copy");
    engine.loadFromModule("00_Canvas", "Canvas_8_composition");

    return app.exec();
}
