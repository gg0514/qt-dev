#include <QGuiApplication>
#include <QQmlApplicationEngine>

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;
    QObject::connect(
        &engine,
        &QQmlApplicationEngine::objectCreationFailed,
        &app,
        []() { QCoreApplication::exit(-1); },
        Qt::QueuedConnection);

    //engine.loadFromModule("00_Controls", "Ex1_busyindicator");
    //engine.loadFromModule("00_Controls", "Ex2_button");
    //engine.loadFromModule("00_Controls", "Ex3_checkbox");

    //engine.loadFromModule("00_Controls", "Ex4_combobox");
    //engine.loadFromModule("00_Controls", "Ex5_groupbox");
    //engine.loadFromModule("00_Controls", "Ex6_label");

    //engine.loadFromModule("00_Controls", "Ex7_progressbar");
    //engine.loadFromModule("00_Controls", "Ex8_radiobutton");
    //engine.loadFromModule("00_Controls", "Ex9_slider_event");

    //engine.loadFromModule("00_Controls", "Ex10_spinbox_event");
    //engine.loadFromModule("00_Controls", "Ex11_switch");
    //engine.loadFromModule("00_Controls", "Ex12_textarea");

    //engine.loadFromModule("00_Controls", "Ex13_textfield");
    engine.loadFromModule("00_Controls", "Ex14_style");


    return app.exec();
}




