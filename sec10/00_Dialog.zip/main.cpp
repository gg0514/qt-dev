#include <QGuiApplication>
#include <QQmlApplicationEngine>

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;
    QObject::connect(
        &engine,
        &QQmlApplicationEngine::objectCreationFailed,
        &app,
        []() { QCoreApplication::exit(-1); },
        Qt::QueuedConnection);

    engine.loadFromModule("00_Dialog", "Ex1");
    //engine.loadFromModule("00_Dialog", "Ex2");
    //engine.loadFromModule("00_Dialog", "Ex3");
    //engine.loadFromModule("00_Dialog", "Ex4");

    return app.exec();
}
