#include <QGuiApplication>
#include <QQmlApplicationEngine>

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;
    QObject::connect(
        &engine,
        &QQmlApplicationEngine::objectCreationFailed,
        &app,
        []() { QCoreApplication::exit(-1); },
        Qt::QueuedConnection);

    engine.loadFromModule("01_CalendarExample", "Calendar1");
    //engine.loadFromModule("01_CalendarExample", "Calendar2");
    //engine.loadFromModule("01_CalendarExample", "Calendar3");
    //engine.loadFromModule("01_CalendarExample", "Calendar4");
    //engine.loadFromModule("01_CalendarExample", "Calendar5");

    return app.exec();
}
