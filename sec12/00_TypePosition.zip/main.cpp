#include <QGuiApplication>
#include <QQmlApplicationEngine>

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;
    QObject::connect(
        &engine,
        &QQmlApplicationEngine::objectCreationFailed,
        &app,
        []() { QCoreApplication::exit(-1); },
        Qt::QueuedConnection);

    engine.loadFromModule("00_TypePosition", "Ex1_column");
    //engine.loadFromModule("00_TypePosition", "Ex2_row");
    //engine.loadFromModule("00_TypePosition", "Ex3_flow");
    //engine.loadFromModule("00_TypePosition", "Ex4_grid");
    //engine.loadFromModule("00_TypePosition", "Ex5_positioner");

    return app.exec();
}
