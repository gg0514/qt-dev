// factorial.js

function factorial(a)
{
    a = parseInt(a);

    return a - 1;
}
